import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import { motion } from 'motion/react';
import { ArrowRight, Check, CircleAlert, Eye, EyeOff, LoaderCircle, Lock, Mail, UserRound } from 'lucide-react';
import AuthApi from '../api/AuthApi';
import { useAuthStore } from '../stores/authStore';
import AuthLayout from '../layouts/AuthLayout';
import AppLogo from '../components/ui/AppLogo';
import Button from '../components/ui/Button';
import TextField from '../components/ui/TextField';
import { cn } from '../lib/cn';

const MODE_LOGIN = 'login';
const MODE_SIGNUP = 'signup';

const loginSchema = z.object({
  email: z.string().email('Please enter a valid email'),
  password: z.string().min(6, 'Password must be at least 6 characters'),
});

const signupSchema = loginSchema.extend({
  name: z.string().trim().min(2, 'Name must be at least 2 characters'),
});

const PAGE_TEXT = {
  [MODE_LOGIN]: {
    title: 'Welcome Back',
    subtitle: 'Sign in to your Chibi Room account',
    submit: 'Sign In',
    submitting: 'Signing in...',
    switchQuestion: "Don't have an account?",
    switchAction: 'Create Account',
    passwordAutoComplete: 'current-password',
  },
  [MODE_SIGNUP]: {
    title: 'Create Account',
    subtitle: 'Join Chibi Room in a few seconds',
    submit: 'Create Account',
    submitting: 'Creating account...',
    switchQuestion: 'Already have an account?',
    switchAction: 'Sign In',
    passwordAutoComplete: 'new-password',
  },
};

// --- Login pihak ketiga (OAuth) ----------------------------------------------
// Fungsinya sengaja dikosongkan dulu. Isi saat integrasi OAuth dibuat.

function handleGoogleLogin() {
  // TODO: arahkan ke endpoint OAuth Google di backend.
}

function handleGithubLogin() {
  // TODO: arahkan ke endpoint OAuth GitHub di backend.
}

function handleMicrosoftLogin() {
  // TODO: arahkan ke endpoint OAuth Microsoft di backend.
}

function handleForgotPassword() {
  // TODO: tampilkan form reset password.
}

const SOCIAL_PROVIDERS = [
  { label: 'Google', onClick: handleGoogleLogin },
  { label: 'GitHub', onClick: handleGithubLogin },
  { label: 'Microsoft', onClick: handleMicrosoftLogin },
];

// -----------------------------------------------------------------------------

function RememberMeCheckbox(props) {
  return (
    <label className="flex min-h-11 cursor-pointer select-none items-center gap-2.5 text-sm text-ink">
      <input
        type="checkbox"
        className="peer sr-only"
        checked={props.checked}
        onChange={(event) => props.onChange(event.target.checked)}
      />
      <span
        className={cn(
          'flex h-5 w-5 items-center justify-center rounded-sm border transition-colors',
          'peer-focus-visible:ring-2 peer-focus-visible:ring-brand-500 peer-focus-visible:ring-offset-2 peer-focus-visible:ring-offset-surface',
          props.checked && 'border-brand-600 bg-brand-600',
          !props.checked && 'border-line bg-surface',
        )}
        aria-hidden="true"
      >
        {props.checked && <Check className="h-3.5 w-3.5 text-white" strokeWidth={3} />}
      </span>
      Remember me
    </label>
  );
}

function PasswordVisibilityToggle(props) {
  let Icon = EyeOff;
  let label = 'Show password';

  if (props.isVisible) {
    Icon = Eye;
    label = 'Hide password';
  }

  return (
    <button
      type="button"
      onClick={props.onToggle}
      className="rounded-sm p-1 text-ink-muted transition-colors hover:text-ink"
      aria-label={label}
      title={label}
    >
      <Icon className="h-5 w-5" />
    </button>
  );
}

export default function LoginPage() {
  const setAuth = useAuthStore((state) => state.setAuth);

  const [mode, setMode] = useState(MODE_LOGIN);
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState(null);
  const [isPasswordVisible, setIsPasswordVisible] = useState(false);
  const [rememberMe, setRememberMe] = useState(true);

  let schema = loginSchema;
  if (mode === MODE_SIGNUP) {
    schema = signupSchema;
  }

  const form = useForm({ resolver: zodResolver(schema) });
  const fieldErrors = form.formState.errors;
  const text = PAGE_TEXT[mode];

  async function handleValidSubmit(formValues) {
    setIsLoading(true);
    setErrorMessage(null);

    try {
      let result;

      if (mode === MODE_LOGIN) {
        result = await AuthApi.login({ email: formValues.email, password: formValues.password });
      } else {
        result = await AuthApi.signup(formValues);
      }

      setAuth(result.token, result.user, rememberMe);
    } catch (error) {
      setErrorMessage(error.message || 'Authentication failed');
    } finally {
      setIsLoading(false);
    }
  }

  function switchMode() {
    setErrorMessage(null);
    form.clearErrors();

    if (mode === MODE_LOGIN) {
      setMode(MODE_SIGNUP);
    } else {
      setMode(MODE_LOGIN);
    }
  }

  function getFieldError(fieldName) {
    if (fieldErrors[fieldName]) {
      return fieldErrors[fieldName].message;
    }

    return null;
  }

  let passwordInputType = 'password';
  if (isPasswordVisible) {
    passwordInputType = 'text';
  }

  return (
    <AuthLayout>
      <motion.main
        initial={{ opacity: 0, y: 24 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.45, ease: 'easeOut' }}
        className="rounded-xl border border-line bg-surface px-6 py-9 shadow-lg sm:px-9"
      >
        <div className="flex flex-col items-center text-center">
          <AppLogo size="lg" />
          <p className="mt-3 text-[34px] font-bold leading-none tracking-tight text-ink">Chibi Room</p>
          <p className="mt-2 text-xs font-medium uppercase tracking-[0.18em] text-ink-muted">AI + Real-time Messaging</p>

          <motion.div key={mode} initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.25 }}>
            <h1 className="mt-9 text-[26px] font-semibold text-ink">{text.title}</h1>
            <p className="mt-1.5 text-base text-ink-muted">{text.subtitle}</p>
          </motion.div>
        </div>

        <form onSubmit={form.handleSubmit(handleValidSubmit)} className="mt-8 space-y-5" noValidate>
          {mode === MODE_SIGNUP && (
            <TextField
              id="name"
              label="Name"
              icon={UserRound}
              placeholder="Your full name"
              autoComplete="name"
              disabled={isLoading}
              error={getFieldError('name')}
              {...form.register('name')}
            />
          )}

          <TextField
            id="email"
            type="email"
            label="Email"
            icon={Mail}
            placeholder="you@example.com"
            autoComplete="email"
            disabled={isLoading}
            error={getFieldError('email')}
            {...form.register('email')}
          />

          <TextField
            id="password"
            type={passwordInputType}
            label="Password"
            icon={Lock}
            placeholder="Enter your password"
            autoComplete={text.passwordAutoComplete}
            disabled={isLoading}
            error={getFieldError('password')}
            trailing={
              <PasswordVisibilityToggle
                isVisible={isPasswordVisible}
                onToggle={() => setIsPasswordVisible(!isPasswordVisible)}
              />
            }
            {...form.register('password')}
          />

          <div className="flex items-center justify-between gap-3">
            <RememberMeCheckbox checked={rememberMe} onChange={setRememberMe} />

            {mode === MODE_LOGIN && (
              <button
                type="button"
                onClick={handleForgotPassword}
                className="min-h-11 text-sm font-semibold text-brand-600 transition-colors hover:text-brand-700 dark:text-brand-300"
              >
                Forgot password?
              </button>
            )}
          </div>

          {errorMessage && (
            <div
              className="flex items-center gap-2.5 rounded-md border border-danger/30 bg-danger/10 px-4 py-3 text-sm text-danger"
              role="alert"
            >
              <CircleAlert className="h-5 w-5 shrink-0" aria-hidden="true" />
              {errorMessage}
            </div>
          )}

          <Button type="submit" size="md" fullWidth disabled={isLoading} className="shadow-md">
            {isLoading && <LoaderCircle className="h-5 w-5 animate-spin" aria-hidden="true" />}
            {isLoading && text.submitting}
            {!isLoading && text.submit}
            {!isLoading && <ArrowRight className="h-5 w-5" aria-hidden="true" />}
          </Button>
        </form>

        <div className="my-7 flex items-center gap-4">
          <span className="h-px flex-1 bg-line" />
          <span className="text-sm text-ink-muted">or continue with</span>
          <span className="h-px flex-1 bg-line" />
        </div>

        <div className="grid grid-cols-3 gap-3">
          {SOCIAL_PROVIDERS.map((provider) => (
            <Button key={provider.label} variant="outline" size="sm" onClick={provider.onClick} disabled={isLoading}>
              {provider.label}
            </Button>
          ))}
        </div>

        <p className="mt-7 text-center text-sm text-ink-muted">
          {text.switchQuestion}{' '}
          <button
            type="button"
            onClick={switchMode}
            className="font-semibold text-brand-600 transition-colors hover:text-brand-700 dark:text-brand-300"
          >
            {text.switchAction}
          </button>
        </p>
      </motion.main>
    </AuthLayout>
  );
}
